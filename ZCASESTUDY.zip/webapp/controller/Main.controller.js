sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel"
], function (Controller, ODataModel) {
	"use strict";

	return Controller.extend("sap.trainingZCASESTUDY.controller.Main", {

 //STEP1 - REGISTER MODEL - BEGIN
		onInit: function () {
			var sUrl = "/sap/opu/odata/sap/ZMATJOIN_CDS/";
			var oModel = new ODataModel(sUrl, {
				useBatch: false
			});

			this.getView().setModel(oModel);
		}
 //STEP1 - REGISTER MODEL - END
	});
});